﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prueba_ArbolExpresion
{
    public partial class Form1 : Form
    {
        private Nodo Raiz;
        Arbol arbol=new Arbol();
        Graphics g;


        public Form1()
        {
            InitializeComponent();
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {
            if (txtIngresar.Text != "")
            {
                arbol.Insertar(txtIngresar.Text);
               Raiz = arbol.CrearArbol();
                arbol.Limpiar();
                lblPre.Text=arbol.InsertarPre(Raiz);
                lblIn.Text=arbol.InsertarIn(Raiz);
                lblPos.Text=arbol.InsertarPos(Raiz);

                Refresh();
                Refresh();
            }
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(this.BackColor);
            e.Graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;//para ajustar el texto
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;//Calidad de los graficos
            g = e.Graphics;
            //Creamos un objeto de la clase Font 
            Font fuente = new Font("Arial", 15);//Asignamos la fuente y el tamaño
            arbol.DibujarArbol(g, fuente, Brushes.Pink, Brushes.Blue, Pens.Black, Brushes.Blue);
        }
    }
    }
