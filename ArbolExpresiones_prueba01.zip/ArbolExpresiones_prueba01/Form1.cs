﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ArbolExpresiones_prueba01
{
    public partial class Form1 : Form
    {
        private Nodo raiz;
        private Arbol arbol;
        Grafico grafico;

        public Form1()
        {
            InitializeComponent();
            arbol = new Arbol();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnEjecutar_Click(object sender, EventArgs e)
        {
            if (txtExpresion.Text != " ")
            {
                arbol.InsertarEnCola(txtExpresion.Text);
                raiz = arbol.CrearArbol();
                arbol.Limpiar();
                lblPre.Text = arbol.InsertarPre(raiz);
                lblIn.Text = arbol.InsertarIn(raiz);
                lblPost.Text = arbol.InsertarPost(raiz);
                grafico = new Grafico(arbol.nodoDot);
                grafico.DrawTree();
                ShowTree();
            }
            else
            {
                MessageBox.Show("Debes ingresar una expresion aritmetica", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
        private void ShowTree()
        {
            if (File.Exists(@"C:\Users\Francisco\Imagen.png"))
            {
                using (FileStream img = new FileStream(@"C:\Users\Francisco\Imagen.png", FileMode.Open, FileAccess.Read))
                {
                    pbImagen.Image = Bitmap.FromStream(img);
                }
            }
            else
            {
                MessageBox.Show("No se ha podido crear el archivo", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            pbImagen.Refresh();
        }
    }
}

