﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Form_ArbolExpresion
{
    public partial class FormArbol : Form
    {
        public FormArbol()
        {
            InitializeComponent();
        }

        public void AbrirFormulario<MiForm>() where MiForm : Form, new()
        {
            //Declaramos un Form y lo llamamos formulario
            Form formulario;
            formulario = panelContenedor.Controls.OfType<MiForm>().FirstOrDefault();//Busca en la 
            //coleccion el formulario si el formulario o instancia no existe 
            if (formulario == null)
            {
                //Creamos una nueva instancia
                formulario = new MiForm();
                formulario.TopLevel = false;//Indicamos que el formulario que se use sera secundario
                formulario.Dock = DockStyle.Fill;//Permite que el formulario se acople al panel contenedor
                //Agregamos el formulario a la coleccion de controles del panel
                panelContenedor.Controls.Add(formulario);
                //Especificamos la propiedad tag
                panelContenedor.Tag = formulario;
                formulario.Show();//Se encarga de mostrar
                formulario.FormClosed += new FormClosedEventHandler(CloseForms);
            }
            //Si el formulario o instancia existe
            else
            {
                formulario.BringToFront();
            }

        }

        #region CloseForms 
        //Metodo para que al cerrar los formularios los botones regresen a su color original
        private void CloseForms(object sender, FormClosedEventArgs e)
        {
           /* if (Application.OpenForms["Insertar Expresión"] == null)
            {
                btnInsertarE.BackColor = Color.FromArgb(54, 51, 51);
            }
            */
            if (Application.OpenForms["Grafico"] == null)
            {
                btnGrafico.BackColor = Color.FromArgb(54, 51, 51);
            }
            /*
            if (Application.OpenForms["GuardarBD"] == null)
            {
                btnGuardarBD.BackColor = Color.FromArgb(54, 51, 51);
            }
            if (Application.OpenForms["MostrarE"] == null)
            {
                btnMostrarE.BackColor = Color.FromArgb(54, 51, 51);
            }
            if (Application.OpenForms["Inorden"] == null)
            {
                btnInorden.BackColor = Color.FromArgb(54, 51, 51);
            }
            if (Application.OpenForms["Posorden"] == null)
            {
                btnPosorden.BackColor = Color.FromArgb(54, 51, 51);
            }
            if (Application.OpenForms["Preorden"] == null)
            {
                btnPreorden.BackColor = Color.FromArgb(54, 51, 51);
            }
            */

        }
        #endregion

        #region Color Cambio de los botones
        private void ColorCambioButton()
        {
            btnInsertarE.BackColor = Color.FromArgb(54, 51, 51);
            btnGrafico.BackColor = Color.FromArgb(54, 51, 51);
            btnGuardarBD.BackColor = Color.FromArgb(54, 51, 51);
            btnMostrarE.BackColor = Color.FromArgb(54, 51, 51);
            btnInorden.BackColor = Color.FromArgb(54, 51, 51);
            btnPosorden.BackColor = Color.FromArgb(54, 51, 51);
            btnPreorden.BackColor = Color.FromArgb(54, 51, 51);
        }
        #endregion

        #region Botones 
        //Metodo para que al presionar el boton se cambie de color
        private void btnInsertarE_Click(object sender, EventArgs e)
        {
            btnInsertarE.BackColor = Color.FromArgb(225, 100, 40);
        }

        private void btnGrafico_Click(object sender, EventArgs e)
        {
            btnGrafico.BackColor = Color.FromArgb(225, 100, 40);
        }

        private void btnGuardarBD_Click(object sender, EventArgs e)
        {
            btnGuardarBD.BackColor = Color.FromArgb(225, 100, 40);
        }

        private void btnMostrarE_Click(object sender, EventArgs e)
        {
            subMenuExpresiones.Visible = true;
            btnMostrarE.BackColor = Color.FromArgb(225, 100, 40);

        }

        private void btnInorden_Click(object sender, EventArgs e)
        {
            btnInorden.BackColor = Color.FromArgb(225, 100, 40);
            subMenuExpresiones.Visible = false;
        }

        private void btnPosorden_Click(object sender, EventArgs e)
        {
            btnPosorden.BackColor = Color.FromArgb(225, 100, 40);
            subMenuExpresiones.Visible = false;
        }

        private void btnPreorden_Click(object sender, EventArgs e)
        {
            btnPreorden.BackColor = Color.FromArgb(225, 100, 40);
            subMenuExpresiones.Visible = false;
        }
        #endregion

    }
}
