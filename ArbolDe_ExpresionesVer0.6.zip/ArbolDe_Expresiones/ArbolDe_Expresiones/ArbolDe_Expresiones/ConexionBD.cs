﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;//libreria que nos permite usar diversos comandos para poder acceder a la base de datos
using System.Windows.Forms;//Utilizamos este using para poder acceder a los messagebox
namespace ArbolDe_Expresiones
{
    class ConexionBD
    {
        //Variable que almacena la url para que podamos conectarnos a la bae de datos
        //string cadena = "Data Source=LAPTOP-5T4NHP0F\\SQLEXPRESS;Initial Catalog=DB_Expresiones; Integrated Security=True";
        string cadena = "Data Source=DESKTOP-DHU5OAE\\SQLEXPRESS;Initial Catalog=DB_Expresiones; Integrated Security=True";
        //Objeto para poder tener acceso a la clase SqlConnection
        public SqlConnection conectarBD = new SqlConnection();

        //Constructor clase
        public ConexionBD()
        {
            //le pasamos el dato almacenado en cadena
            conectarBD.ConnectionString = cadena;
        }
        //metodo que nos permite iniciar la conexion a la base de datos
        public void IniciarConexion()
        {
            //try catch para asegurar que no haya errores
            try
            {
                //abrimos conexion y enviamos un mensaje a consola para avisar de la conexion
                conectarBD.Open();
                Console.WriteLine("CONECTADO A LA BASE DE DATOS");
            }
            catch (Exception ex)
            {
                //si se produce algun error enviamos un messagebox
                MessageBox.Show("Error al conectar a la base de datos " + ex);
            }
        }
        //metodo que nos permite cerrar la conexion
        public void TerminarConexion()
        {
            conectarBD.Close();
            Console.WriteLine("Se a cerrado la conexion");
        }
    }
}
