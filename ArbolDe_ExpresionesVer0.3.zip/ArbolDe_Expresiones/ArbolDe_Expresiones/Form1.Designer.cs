﻿namespace ArbolDe_Expresiones
{
    partial class FormArbol
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormArbol));
            this.MenuVertical = new System.Windows.Forms.Panel();
            this.lbl_arbExpr = new System.Windows.Forms.Label();
            this.btnGrafico = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.subMenuExpresiones = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnPreorden = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnPosorden = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.btnInorden = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnMostrarE = new System.Windows.Forms.Button();
            this.btnInsertarE = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnGuardarBD = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnBuscarS = new System.Windows.Forms.Button();
            this.txtInsertar = new System.Windows.Forms.TextBox();
            this.PanelGrafico = new System.Windows.Forms.Panel();
            this.MenuVertical.SuspendLayout();
            this.subMenuExpresiones.SuspendLayout();
            this.SuspendLayout();
            // 
            // MenuVertical
            // 
            this.MenuVertical.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.MenuVertical.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.MenuVertical.Controls.Add(this.lbl_arbExpr);
            this.MenuVertical.Controls.Add(this.btnGrafico);
            this.MenuVertical.Controls.Add(this.panel6);
            this.MenuVertical.Controls.Add(this.subMenuExpresiones);
            this.MenuVertical.Controls.Add(this.panel5);
            this.MenuVertical.Controls.Add(this.btnMostrarE);
            this.MenuVertical.Controls.Add(this.btnInsertarE);
            this.MenuVertical.Controls.Add(this.panel1);
            this.MenuVertical.Controls.Add(this.btnGuardarBD);
            this.MenuVertical.Controls.Add(this.panel2);
            this.MenuVertical.Location = new System.Drawing.Point(0, 0);
            this.MenuVertical.Name = "MenuVertical";
            this.MenuVertical.Size = new System.Drawing.Size(246, 576);
            this.MenuVertical.TabIndex = 4;
            // 
            // lbl_arbExpr
            // 
            this.lbl_arbExpr.AutoSize = true;
            this.lbl_arbExpr.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_arbExpr.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl_arbExpr.Location = new System.Drawing.Point(13, 46);
            this.lbl_arbExpr.Name = "lbl_arbExpr";
            this.lbl_arbExpr.Size = new System.Drawing.Size(237, 24);
            this.lbl_arbExpr.TabIndex = 15;
            this.lbl_arbExpr.Text = "ÁRBOL DE EXPRESIÓN";
            // 
            // btnGrafico
            // 
            this.btnGrafico.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.btnGrafico.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGrafico.FlatAppearance.BorderSize = 0;
            this.btnGrafico.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(136)))), ((int)(((byte)(64)))));
            this.btnGrafico.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGrafico.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGrafico.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(233)))), ((int)(((byte)(233)))));
            this.btnGrafico.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGrafico.Location = new System.Drawing.Point(17, 172);
            this.btnGrafico.Name = "btnGrafico";
            this.btnGrafico.Size = new System.Drawing.Size(221, 44);
            this.btnGrafico.TabIndex = 13;
            this.btnGrafico.Text = "Gráfico Arbol";
            this.btnGrafico.UseVisualStyleBackColor = false;
            this.btnGrafico.Click += new System.EventHandler(this.btnGrafico_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(189)))), ((int)(((byte)(155)))));
            this.panel6.Location = new System.Drawing.Point(7, 172);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(10, 44);
            this.panel6.TabIndex = 14;
            // 
            // subMenuExpresiones
            // 
            this.subMenuExpresiones.Controls.Add(this.panel3);
            this.subMenuExpresiones.Controls.Add(this.btnPreorden);
            this.subMenuExpresiones.Controls.Add(this.panel4);
            this.subMenuExpresiones.Controls.Add(this.btnPosorden);
            this.subMenuExpresiones.Controls.Add(this.panel8);
            this.subMenuExpresiones.Controls.Add(this.btnInorden);
            this.subMenuExpresiones.Location = new System.Drawing.Point(59, 356);
            this.subMenuExpresiones.Name = "subMenuExpresiones";
            this.subMenuExpresiones.Size = new System.Drawing.Size(181, 151);
            this.subMenuExpresiones.TabIndex = 9;
            this.subMenuExpresiones.Visible = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(189)))), ((int)(((byte)(155)))));
            this.panel3.Location = new System.Drawing.Point(3, 103);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(10, 44);
            this.panel3.TabIndex = 4;
            // 
            // btnPreorden
            // 
            this.btnPreorden.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.btnPreorden.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPreorden.FlatAppearance.BorderSize = 0;
            this.btnPreorden.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(136)))), ((int)(((byte)(64)))));
            this.btnPreorden.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPreorden.Font = new System.Drawing.Font("Bookman Old Style", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPreorden.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(233)))), ((int)(((byte)(233)))));
            this.btnPreorden.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPreorden.Location = new System.Drawing.Point(10, 103);
            this.btnPreorden.Name = "btnPreorden";
            this.btnPreorden.Size = new System.Drawing.Size(168, 44);
            this.btnPreorden.TabIndex = 11;
            this.btnPreorden.Text = "Preorden";
            this.btnPreorden.UseVisualStyleBackColor = false;
            this.btnPreorden.Click += new System.EventHandler(this.btnPreorden_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(189)))), ((int)(((byte)(155)))));
            this.panel4.Location = new System.Drawing.Point(3, 53);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(10, 44);
            this.panel4.TabIndex = 3;
            // 
            // btnPosorden
            // 
            this.btnPosorden.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.btnPosorden.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPosorden.FlatAppearance.BorderSize = 0;
            this.btnPosorden.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(136)))), ((int)(((byte)(64)))));
            this.btnPosorden.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPosorden.Font = new System.Drawing.Font("Bookman Old Style", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPosorden.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(233)))), ((int)(((byte)(233)))));
            this.btnPosorden.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPosorden.Location = new System.Drawing.Point(10, 53);
            this.btnPosorden.Name = "btnPosorden";
            this.btnPosorden.Size = new System.Drawing.Size(168, 44);
            this.btnPosorden.TabIndex = 10;
            this.btnPosorden.Text = "Posorden";
            this.btnPosorden.UseVisualStyleBackColor = false;
            this.btnPosorden.Click += new System.EventHandler(this.btnPosorden_Click);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(189)))), ((int)(((byte)(155)))));
            this.panel8.Location = new System.Drawing.Point(3, 3);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(10, 44);
            this.panel8.TabIndex = 2;
            // 
            // btnInorden
            // 
            this.btnInorden.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.btnInorden.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInorden.FlatAppearance.BorderSize = 0;
            this.btnInorden.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(136)))), ((int)(((byte)(64)))));
            this.btnInorden.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInorden.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInorden.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(233)))), ((int)(((byte)(233)))));
            this.btnInorden.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnInorden.Location = new System.Drawing.Point(10, 3);
            this.btnInorden.Name = "btnInorden";
            this.btnInorden.Size = new System.Drawing.Size(168, 44);
            this.btnInorden.TabIndex = 1;
            this.btnInorden.Text = "Inorden";
            this.btnInorden.UseVisualStyleBackColor = false;
            this.btnInorden.Click += new System.EventHandler(this.btnInorden_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(189)))), ((int)(((byte)(155)))));
            this.panel5.Location = new System.Drawing.Point(6, 297);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(10, 44);
            this.panel5.TabIndex = 8;
            // 
            // btnMostrarE
            // 
            this.btnMostrarE.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.btnMostrarE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMostrarE.FlatAppearance.BorderSize = 0;
            this.btnMostrarE.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(136)))), ((int)(((byte)(64)))));
            this.btnMostrarE.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMostrarE.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMostrarE.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(233)))), ((int)(((byte)(233)))));
            this.btnMostrarE.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMostrarE.Location = new System.Drawing.Point(13, 297);
            this.btnMostrarE.Name = "btnMostrarE";
            this.btnMostrarE.Size = new System.Drawing.Size(225, 44);
            this.btnMostrarE.TabIndex = 3;
            this.btnMostrarE.Text = "Mostrar Expresión";
            this.btnMostrarE.UseVisualStyleBackColor = false;
            this.btnMostrarE.Click += new System.EventHandler(this.btnMostrarE_Click);
            // 
            // btnInsertarE
            // 
            this.btnInsertarE.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.btnInsertarE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInsertarE.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnInsertarE.FlatAppearance.BorderSize = 0;
            this.btnInsertarE.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnInsertarE.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(136)))), ((int)(((byte)(64)))));
            this.btnInsertarE.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInsertarE.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInsertarE.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(233)))), ((int)(((byte)(233)))));
            this.btnInsertarE.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnInsertarE.Location = new System.Drawing.Point(17, 113);
            this.btnInsertarE.Name = "btnInsertarE";
            this.btnInsertarE.Size = new System.Drawing.Size(221, 44);
            this.btnInsertarE.TabIndex = 7;
            this.btnInsertarE.Text = "Insertar Expresión";
            this.btnInsertarE.UseVisualStyleBackColor = false;
            this.btnInsertarE.Click += new System.EventHandler(this.btnInsertarE_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(189)))), ((int)(((byte)(155)))));
            this.panel1.Location = new System.Drawing.Point(7, 113);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(10, 44);
            this.panel1.TabIndex = 12;
            // 
            // btnGuardarBD
            // 
            this.btnGuardarBD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.btnGuardarBD.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGuardarBD.FlatAppearance.BorderSize = 0;
            this.btnGuardarBD.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(136)))), ((int)(((byte)(64)))));
            this.btnGuardarBD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGuardarBD.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardarBD.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(233)))), ((int)(((byte)(233)))));
            this.btnGuardarBD.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGuardarBD.Location = new System.Drawing.Point(16, 234);
            this.btnGuardarBD.Name = "btnGuardarBD";
            this.btnGuardarBD.Size = new System.Drawing.Size(222, 44);
            this.btnGuardarBD.TabIndex = 6;
            this.btnGuardarBD.Text = "Guardar en BD";
            this.btnGuardarBD.UseVisualStyleBackColor = false;
            this.btnGuardarBD.Click += new System.EventHandler(this.btnGuardarBD_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(189)))), ((int)(((byte)(155)))));
            this.panel2.Location = new System.Drawing.Point(6, 234);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(10, 44);
            this.panel2.TabIndex = 11;
            // 
            // btnBuscarS
            // 
            this.btnBuscarS.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.btnBuscarS.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(65)))), ((int)(((byte)(65)))));
            this.btnBuscarS.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBuscarS.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarS.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(233)))), ((int)(((byte)(233)))));
            this.btnBuscarS.Location = new System.Drawing.Point(802, 23);
            this.btnBuscarS.Name = "btnBuscarS";
            this.btnBuscarS.Size = new System.Drawing.Size(122, 31);
            this.btnBuscarS.TabIndex = 6;
            this.btnBuscarS.Text = "Buscar Simbolo";
            this.btnBuscarS.UseVisualStyleBackColor = false;
            // 
            // txtInsertar
            // 
            this.txtInsertar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInsertar.Location = new System.Drawing.Point(320, 23);
            this.txtInsertar.Name = "txtInsertar";
            this.txtInsertar.Size = new System.Drawing.Size(453, 29);
            this.txtInsertar.TabIndex = 5;
            // 
            // PanelGrafico
            // 
            this.PanelGrafico.Location = new System.Drawing.Point(295, 83);
            this.PanelGrafico.Name = "PanelGrafico";
            this.PanelGrafico.Size = new System.Drawing.Size(649, 447);
            this.PanelGrafico.TabIndex = 8;
            this.PanelGrafico.Paint += new System.Windows.Forms.PaintEventHandler(this.PanelGrafico_Paint);
            // 
            // FormArbol
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(231)))), ((int)(((byte)(225)))));
            this.ClientSize = new System.Drawing.Size(968, 576);
            this.Controls.Add(this.PanelGrafico);
            this.Controls.Add(this.btnBuscarS);
            this.Controls.Add(this.txtInsertar);
            this.Controls.Add(this.MenuVertical);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormArbol";
            this.Text = "Arbol de expresiones";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.MenuVertical.ResumeLayout(false);
            this.MenuVertical.PerformLayout();
            this.subMenuExpresiones.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel MenuVertical;
        private System.Windows.Forms.Label lbl_arbExpr;
        private System.Windows.Forms.Button btnGrafico;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel subMenuExpresiones;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnPreorden;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnPosorden;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button btnInorden;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btnMostrarE;
        private System.Windows.Forms.Button btnInsertarE;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnGuardarBD;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnBuscarS;
        private System.Windows.Forms.TextBox txtInsertar;
        private System.Windows.Forms.Panel PanelGrafico;
    }
}

